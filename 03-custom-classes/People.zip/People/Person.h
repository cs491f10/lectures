//
//  Person.h
//  People
//

#import <Foundation/Foundation.h>


@interface Person : NSObject {
	NSString * _name;
	int _age;
}

-(id)initWithName:(NSString *)name;
-(id)initWithName:(NSString *)name age:(int)age;

-(int)age;
-(void)setAge:(int)age;
-(NSString *)name;
-(void)setName:(NSString *)name;

-(BOOL)isAdult;
-(void)vote;

@end
