#import <Foundation/Foundation.h>
#import "Person.h"

int main (int argc, const char * argv[]) {
    NSAutoreleasePool * pool = [[NSAutoreleasePool alloc] init];

	// instantiate a Person instance
	Person *dwight = [[Person alloc] init];
	Person *jim = [[Person alloc] initWithName:@"Jim" age:32];
	
	// set ivars
	[dwight setName:@"Dwight Schrute"]; 
	[dwight setAge:38];
	
	// dump dwight
	NSLog(@"%@ (%d)", [dwight name], [dwight age]); 
	NSLog(@"is a %@", [dwight isAdult] ? @"Adult" : @"Child");

    // dump Jim
	NSLog(@"%@", jim); 
	[jim vote];

	// release objects
	[dwight release];
	[jim release];
	
	[pool drain];
    return 0;
}
