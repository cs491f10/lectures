//
//  Person.m
//  People
//

#import "Person.h"

@implementation Person

-(id)init { 
	return [self initWithName:@"John Doe" age:30];
}

-(id)initWithName:(NSString *)name { 
	return [self initWithName: name age:30];
}

-(id)initWithName:(NSString *)name age:(int)age { 
	if (self = [super init]) {
		[self setName: name];
		_age = age;
	} 
	return self;
}

-(int)age {
	return _age;
}

-(void)setAge:(int)age {
	_age = age;
}

-(NSString *)name {
	return _name;
}

-(void)setName:(NSString *)name {
	[_name release];
	_name = [name copy];
}

-(BOOL)isAdult {
	return _age > 18;
}

-(void)vote {
	if([self isAdult]) {
		NSLog(@"Going to vote");
	}
}

-(void)dealloc {
	[_name release];
	[super dealloc];
}

-(NSString *)description {
	NSString * result = [[NSString alloc] initWithFormat:@"%@ (%d)", _name, _age];
	return [result autorelease];
}

@end
